const Discord = require("discord.js");
const client = new Discord.Client();
const prefix = '-';

client.on('message', message => {

const args = message.content.slice(prefix.length).trim().split(/+ /);
const command = args.shift().toLowerCase();

if (command === 'borzxygemevent') {
if (!message.content.startsWith(prefix) || message.author.bot) return;

const user = message.author;

if (!args[0]) {
user.send("Provide a word to say in the say command\nExample: !say Hello")
}

const say = args.join(" ");
message.channel.send(say)
message.delete()
}

})

client.login("ODM2NTA4MDQzMzEwNTMwNTkw.YIfA0w.Tbv-LGEjb1RGFC8SAVDhP2JYh7g")
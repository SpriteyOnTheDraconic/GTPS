# GTPS-Server-Status-Bot (C)
* You Only Need Node.js https://nodejs.org/en/download/
* If you have any problem, dm my discord Clayne#5451
## How To Setup?
 1. Download the code
 ![image](https://cdn.discordapp.com/attachments/703227581259841607/742316353616085062/Screenshot_2020-08-10-16-37-19-878_com.microsoft.rdc.android.png)
 2. Extract it to ur gtps folder
 2. Run install.bat
 3. After the install.bat force closing
 4. Edit the botconfig.json
 5. Run startbot.bat
 6. Enjoy
## Attention
 * rename our exe to enet.exe
 * at botconfig.json, put your token bot, channel id & players, worlds, guilds folder name on ur source files
# Changelogs
 ### New Changelogs 12-08-2020: 
   * Added World, Players & Guilds file data count.
 ### New Changelogs 14-08-2020:
   * Added botconfig.json for more easily you change token bot & channel id.
 ### New Changelogs 16-08-2020:
   * Now, You can edit players folder, worlds folder & guilds folder on botconfig.json
# Warning
* This source code not for sale, because this is common source.

Thank You!
